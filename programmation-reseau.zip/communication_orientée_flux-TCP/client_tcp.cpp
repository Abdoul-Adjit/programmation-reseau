#include <sys/socket.h>
#include <iostream>
#include <unistd.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <arpa/inet.h>
#include <string>

using namespace std;

int main()
{
    int sock = socket(PF_INET, SOCK_STREAM, 0); // On crée un socket
    sockaddr_in adresse;                        // On crée une adresse qui est l'adresse du serveur
    adresse.sin_family = PF_INET;
    adresse.sin_port = htons(9600);                                       // On associe cette adresse au port 9600
    int connexion = connect(sock, (sockaddr *)&adresse, sizeof(adresse)); // On connecte notre socket à l'adresse du serveur
    char buf[4096];                                                       // On crée un buffer pour notre client. C'est un tableau de caractère dont la taille (4096) correspond à la taille maximale du message que l'on peut recevoir
    string s = "Hello from client";
    int envoye = write(sock, s.c_str(), s.size()); // On envoie au serveur le message s
    int recu = read(sock, buf, 4096);              // On reçoit du serveur un message que l'on stocke dans le buffer
    cout << string(buf, 0, recu) << endl;          // On affiche le message reçu
    close(sock);
    return 0;
}