#include <sys/socket.h>
#include <iostream>
#include <unistd.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <arpa/inet.h>
#include <string>

using namespace std;

int main()
{
    int sock = socket(PF_INET, SOCK_STREAM, 0); // Création du socket
    sockaddr_in adresse;                        // On crée une adresse qui est l'adresse du serveur
    adresse.sin_family = PF_INET;
    adresse.sin_port = htons(9600);                    // On associe cette adresse au port 9600
    adresse.sin_addr.s_addr = INADDR_ANY;              // En ajoutant cette option on considère que toutes les adresses IP peuvent se connecter à notre serveur
    bind(sock, (sockaddr *)&adresse, sizeof(adresse)); // On lie (bind) notre socket à notre "adresse"
    listen(sock, 5);                                   // Nous écoutons/attendons une connexion à notre socket. Le chiffre 5 indique le nombre de connexion en attente possible avant d'être accepté et a été décidé arbitrairement.
    sockaddr_in client;                                // On crée une adresse "client"
    socklen_t clientTaille = sizeof(client);
    int clientSocket = accept(sock, (sockaddr *)&client, &clientTaille); // Lorsqu'une connexion arrive sur notre socket, on l'accepte.
    close(sock);
    char buf[4096]; // On crée un buffer pour notre serveur. C'est un tableau de caractère dont la taille (4096) correspond à la taille maximale du message que l'on peut recevoir
    while (true)
    {
        int recu = read(clientSocket, buf, 4096); // On stocke dans le buffer le message envoyé par le client.
        cout << string(buf, 0, recu) << endl;     // On affiche le message envoyé par le client
        string s = "Hello from server";
        write(clientSocket, s.c_str(), s.size()); // On envoie au client le message s
    }
    close(clientSocket);
    return 0;
}