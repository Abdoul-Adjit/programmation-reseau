#include <iostream>
#include <unistd.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <arpa/inet.h>
#include <string>
#define PORT 9600;
#define MS 1024;
using namespace std;

int main(int argc, char *argv[])
{
    sockaddr_in server; // On crée l'adresse du serveur
    server.sin_family = PF_INET;
    server.sin_port = htons(9600);               // On associe cette adresse au port 9600
    int client = socket(PF_INET, SOCK_DGRAM, 0); // On crée le socket du client
    while (1)                                    // On crée une boucle qui fait que l'on peut envoyer autant de message que l'on veut au serveur
    {
        string s = "";                                                                            // Message que l'on souhaite envoyer. Ici, on ne limite pas la taille du message
        cin >> s;                                                                                 // Le client saisit son message
        int sendOK = sendto(client, s.c_str(), s.size(), 0, (sockaddr *)&server, sizeof(server)); // On envoie le message "s" au serveur "server".
    }                                                                                             // La fonction c_str() convertit notre string en un tableau de caractères
    close(client);
    return 0;
}