#include <iostream>
#include <unistd.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <arpa/inet.h>
#define PORT 9600;
#define MS 1024;
using namespace std;

int main(int argc, char *argv[])
{
    int sock = socket(PF_INET, SOCK_DGRAM, 0); // Création du socket
    sockaddr_in server;                        // On crée une adresse
    server.sin_family = PF_INET;
    server.sin_port = htons(9600);                   // On associe cette adresse au port 9600
    server.sin_addr.s_addr = INADDR_ANY;             // En ajoutant cette option on considère que toutes les adresses IP peuvent se connecter à notre serveur
    bind(sock, (sockaddr *)&server, sizeof(server)); // On lie (bind) le socket à l'adresse "server" que nous avons crée précédemment
    sockaddr_in client;                              // On crée une adresse client
    int clientLength = sizeof(client);               // On crée cette variable qui est associé à la taille de l'adresse du client. On utilisera cette variable plus tard
    while (1)
    {
        char buf[1024];                                                                // On crée un buffer pour notre serveur. C'est un tableau de caractère dont la taille (1024) correspond à la taille maximale du message que l'on peut recevoir
        fill_n(buf, sizeof(buf), 0);                                                   // Cette fonction permet de vider le buffer (tableau buf)
        recvfrom(sock, buf, 1024, 0, (sockaddr *)&client, (socklen_t *)&clientLength); // On enregistre le message reçu sur le socket "sock" dans le buffer. Le message vient du client dont l'adresse est "client". Ce message à une taille de 1024 maximum.
        cout << "Msg reçu : " << buf << endl;                                          // On affiche le message contenu dans buf.
    }
    close(sock); // On ferme le socket
    return 0;
}
